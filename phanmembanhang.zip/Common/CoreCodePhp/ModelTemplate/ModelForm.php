<?php

namespace CoreCodePhp;

class ModelForm extends \PFBC\Form implements IModelForm {

    private static $Option = ["class" => "form-control"];

    __methods__
}
?>

