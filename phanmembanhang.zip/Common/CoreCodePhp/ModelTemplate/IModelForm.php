<?php

namespace CoreCodePhp;

interface IModelForm {
__Code__
}
?>
