<?php

namespace Controller;

interface IController {

    function put();

    function post();

    function delete();

    function index();
}
