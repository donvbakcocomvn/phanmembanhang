<?php

namespace Model\news;

interface newsCategoryIForm {

    public static function Id($val=null);

    public static function Code($val=null);

    public static function Name($val=null);

    public static function Parents($val=null);

    public static function Title($val=null);

    public static function Des($val=null);

    public static function Keyword($val=null);

    public static function Content($val=null);

    public static function Images($val=null);
}
